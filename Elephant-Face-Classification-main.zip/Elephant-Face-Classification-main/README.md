# Elephant-Face-Classification

The files in this folder does the following things:

  (a) Crop.py:- file is extract the head, tusk and trunk of the elephant
  
  (b) train_test_final.py:- create pairwise distance and generate 3 cluster using Agglomerative clustering for train-test-validation
  
  (c) Baseline, VGG-16, VGG-19, ResNet and EfficientNet files are for their respective model
  
  (c) VGG-16 XAI apprach elephant.ipynb: Pretrained VGG-16 was used and explnation produced for the model
